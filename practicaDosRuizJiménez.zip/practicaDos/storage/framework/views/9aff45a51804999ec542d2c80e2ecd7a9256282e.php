

<?php $__env->startSection('link'); ?>

<link rel="stylesheet" href="<?php echo e(url('assets/monedacss/styleMoneda.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('tittle'); ?>

<h4>MONEDA - EDIT</h4>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('messages'); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-info btn-rounded btn-fw mdi mdi-keyboard-backspace"> Back</a>
    <a href="<?php echo e(url('backend/moneda')); ?>" class="btn btn-info btn-rounded btn-fw mdi mdi-coin"> Monedas</a>
    <a href="#" class="btn btn-info btn-rounded btn-fw mdi mdi-delete" data-id="<?php echo e($moneda->id); ?>" data-name="<?php echo e($moneda->name); ?>" data-toggle="modal" data-target="#exampleModal"> Delete</a>

    <form id="formDelete" action="<?php echo e(url('backend/moneda')); ?>" method="POST">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
    </form>
    
    <br>
    <br>
    

    <?php if(Session::get('Result') == 'Fail to update'): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(Session::get('Result')); ?>

        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>

<div class="col-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Moneda</h4>
            <form class="forms-sample" action="<?php echo e(url('backend/moneda/' . $moneda->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="name" placeholder="Name" name="name" value="<?php echo e($moneda->name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="symbol">Symbol</label>
                    <input type="text" maxlength="5" minlength="1" class="form-control" id="symbol" placeholder="Symbol" name="symbol" value="<?php echo e($moneda->symbol); ?>" required>
                </div>
                <div class="form-group">
                    <label for="country">Country</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="country" placeholder="Country" name="country" value="<?php echo e($moneda->country); ?>" required>
                    </div>
                <div class="form-group">
                    <label for="number">Value</label>
                    <input type="number" maxlength="10" class="form-control" id="value" placeholder="Value" name="value" value="<?php echo e($moneda->value); ?>" required>
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" class="form-control" id="date" placeholder="Date" name="date" value="<?php echo e($moneda->date); ?>">
                </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                <a href="<?php echo e(url('backend/moneda')); ?>" class="btn btn-light">Cancel</a>
            </form>
        </div>
    </div>
</div>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Sure to delete?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="add" class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" name="deleteButton">Delete</button>
            </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(url('assets/monedajs/delete.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\practicaDos\resources\views/backend/moneda/edit.blade.php ENDPATH**/ ?>