

<?php $__env->startSection('link'); ?>
<link rel="stylesheet" href="<?php echo e(url('assets/monedacss/styleMoneda.css')); ?>">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('messages'); ?>
    
    <a href="<?php echo e(url('backend/moneda/create')); ?>" class="btn btn-info btn-rounded btn-fw mdi mdi-plus"> Create</a>
   
    <br />
    <br />

    <?php if(Session::get('Op') == 'create'): ?>
        <?php if(Session::get('Result') == 1): ?>
        <div class="alert alert-success" role="alert">
            Moneda (id: <?php echo e(Session::get('Id')); ?>) inserted correctly
        </div>
        <?php else: ?>
        <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('Result')); ?>

        </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(Session::get('Op') == 'update'): ?>
        <?php if(Session::get('Result') == 1): ?>
        <div class="alert alert-success" role="alert">
            Moneda (id: <?php echo e(Session::get('Id')); ?>) updated correctly
        </div>
        <?php else: ?>
        <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('Result')); ?>

        </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(Session::get('Op') == 'delete'): ?>
        <?php if(Session::get('Result') == 1): ?>
        <div class="alert alert-success" role="alert">
            Moneda (id: <?php echo e(Session::get('Id')); ?>) deleted correctly
        </div>
        <?php else: ?>
        <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('Result')); ?>

        </div>
        <?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('tittle'); ?>

<h4>MONEDA - INDEX</h4>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
 
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Symbol</th>
            <th>Country</th>

            <th>Show</th>
            <th>Edit</th>
            <th>Delete</th>

        </tr>
    </thead>
    
    <tbody>
        <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="prueba">
            <td><?php echo e($moneda->id); ?></td>
            <td><?php echo e($moneda->name); ?></td>
            <td><?php echo e($moneda->symbol); ?></td>
            <td><?php echo e($moneda->country); ?></td>

            <td><a href="<?php echo e(url('backend/moneda/' . $moneda->id)); ?>"><i class="mdi mdi-eye"></i></a></td>
            <td><a href="<?php echo e(url('backend/moneda/' . $moneda->id . '/edit')); ?>"><i class="mdi mdi-lead-pencil"></i></a></td>
            <td><a href="#" class="linkDelete"><i class="mdi mdi-delete" data-id="<?php echo e($moneda->id); ?>" data-toggle="modal" data-target="#exampleModal" data-name="<?php echo e($moneda->name); ?>"></i></a></td>



        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

    <form id="formDelete" action="<?php echo e(url('backend/moneda')); ?>" method="POST">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
    </form>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Sure to delete?</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div id="add" class="modal-body">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-primary" name="deleteButton">Delete</button>
        </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(url('assets/monedajs/delete.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\practicaDos\resources\views/backend/moneda/index.blade.php ENDPATH**/ ?>