

<?php $__env->startSection('link'); ?>

<link rel="stylesheet" href="<?php echo e(url('assets/monedacss/styleMoneda.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('tittle'); ?>

<h4>MONEDA - SHOW</h4>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('messages'); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-info btn-rounded btn-fw mdi mdi-keyboard-backspace"> Back</a>
    <a href="<?php echo e(url('backend/moneda')); ?>" class="btn btn-info btn-rounded btn-fw mdi mdi-coin"> Monedas</a>
    <a href="#" class="btn btn-info btn-rounded btn-fw mdi mdi-delete" data-id="<?php echo e($moneda->id); ?>" data-name="<?php echo e($moneda->name); ?>" data-toggle="modal" data-target="#exampleModal"> Delete</a>

    <br />
    <br />

    <form id="formDelete" action="<?php echo e(url('backend/moneda')); ?>" method="POST">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    
    <thead>
        <tr>
            <th>Field</th>
            <th>Value</th>
        </tr>
    </thead>
    
    <tbody>
        
            <tr>
                <td><b>Id</b></td>
                <td><?php echo e($moneda->id); ?></td>
            </tr>
            
            <tr>
                <td><b>Name</b></td>
                <td><?php echo e($moneda->name); ?></td>
            </tr>
            
            <tr>
                <td><b>Symbol</b></td>
                <td><?php echo e($moneda->symbol); ?></td>
            </tr>
            
            <tr>
                <td><b>Country</b></td>
                <td><?php echo e($moneda->country); ?></td>
            </tr>
            
            <tr>
                <td><b>Value</b></td>
                <td><?php echo e($moneda->value); ?></td> 
            </tr>
            
            <?php if($moneda->date): ?>
            
            <tr>
                <td><b>Date</b></td>
                <td><?php echo e($moneda->date); ?></td>
            </tr>
            
            <?php endif; ?>
            

    </tbody>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Sure to delete?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="add" class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" name="deleteButton">Delete</button>
            </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(url('assets/monedajs/delete.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\practicaDos\resources\views/backend/moneda/show.blade.php ENDPATH**/ ?>