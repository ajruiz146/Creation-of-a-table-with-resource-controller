

<?php $__env->startSection('link'); ?>

<link rel="stylesheet" href="<?php echo e(url('assets/monedacss/styleMoneda.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('tittle'); ?>

<h4>MONEDA - CREATE</h4>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('messages'); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-info btn-rounded btn-fw mdi mdi-keyboard-backspace"> Back</a>
    <a href="<?php echo e(url('backend/moneda')); ?>" class="btn btn-info btn-rounded btn-fw mdi mdi-coin"> Monedas</a>

    <br />
    <br />

    <?php if(Session::get('Result') == 'Fail to create'): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(Session::get('Result')); ?>

        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>

<div class="col-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <form class="forms-sample" action="<?php echo e(url('backend/moneda')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="name" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="symbol">Symbol</label>
                    <input type="text" maxlength="5" minlength="1" class="form-control" id="symbol" placeholder="Symbol" name="symbol" value="<?php echo e(old('symbol')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="country">Country</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="country" placeholder="Country" name="country" value="<?php echo e(old('country')); ?>" required>
                    </div>
                <div class="form-group">
                    <label for="number">Value</label>
                    <input type="number" maxlength="10" class="form-control" step="any" id="value" placeholder="Value" name="value" value="<?php echo e(old('value')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" class="form-control" id="date" placeholder="Date" name="date" value="<?php echo e(old('date')); ?>">
                </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                <a href="<?php echo e(url('backend/moneda')); ?>" class="btn btn-light">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Quini\Apache2020\htdocs\laraveles\practicaDos\resources\views/backend/moneda/create.blade.php ENDPATH**/ ?>