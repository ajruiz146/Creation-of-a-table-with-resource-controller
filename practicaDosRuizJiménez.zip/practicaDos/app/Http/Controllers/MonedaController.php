<?php

namespace App\Http\Controllers;

use App\Models\Moneda;
use Illuminate\Http\Request;

class MonedaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $monedas = Moneda::all();
        return view('backend.moneda.index', ['monedas' => $monedas]);

        $enterprises = Enterprise::all();
        
        return view('backend.enterprise.index', ['enterprises' => $enterprises]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.moneda.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $moneda = new Moneda($request->all());
        try {
            $correct = $moneda->save();
        } catch (\Exception $e) {
            $correct = false;
        }
        if($correct) {
            $message = ['Op' => 'create', 'Id' => $moneda->id, 'Result' => $correct];
            return redirect('backend/moneda')->with($message);
        } else {
            $message = ["Op" => "create", "Result" => "Fail to create"];
            return back()->withInput()->with($message);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Moneda  $moneda
     * @return \Illuminate\Http\Response
     */
    public function show(Moneda $moneda)
    {
        return view('backend.moneda.show', ['moneda' => $moneda]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Moneda  $moneda
     * @return \Illuminate\Http\Response
     */
    public function edit(Moneda $moneda)
    {
        return view('backend.moneda.edit', ['moneda' => $moneda]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Moneda  $moneda
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Moneda $moneda)
    {
        try {
            $correct = $moneda->update($request->all());
        } catch (\Exception $e) {
            $correct = 0;
        }

        if($correct) {
            $message = ['Op' => 'update', 'Id' => $moneda->id, 'Result' => $correct];
            return redirect('backend/moneda')->with($message);
        } else {
            $message = ["Op" => "update", "Result" => "Fail to update"];
            return back()->withInput()->with($message);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Moneda  $moneda
     * @return \Illuminate\Http\Response
     */
    public function destroy(Moneda $moneda)
    {
        try {
            $correct = $moneda->delete();
        } catch (\Exception $e) {
            $correct = 0;
        }
        
        if($correct) {
            $message = ['Op' => 'delete', 'Id' => $moneda->id, 'Result' => $correct];
            return redirect('backend/moneda')->with($message);
        } else {
            $message = ["Op" => "delete", "Result" => "Fail to delete"];
            return back()->withInput()->with($message);
        }

    }

    function main() {
        return view('backend.index');
    }
}
