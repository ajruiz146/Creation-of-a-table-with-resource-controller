@extends('backend.base')

@section('link')

<link rel="stylesheet" href="{{ url('assets/monedacss/styleMoneda.css') }}">

@endsection

@section('tittle')

<h4>MONEDA - CREATE</h4>

@endsection

@section('messages')

    <a href="{{ url()->previous() }}" class="btn btn-info btn-rounded btn-fw mdi mdi-keyboard-backspace"> Back</a>
    <a href="{{ url('backend/moneda') }}" class="btn btn-info btn-rounded btn-fw mdi mdi-coin"> Monedas</a>

    <br />
    <br />

    @if(Session::get('Result') == 'Fail to create')
        <div class="alert alert-danger" role="alert">
            {{ Session::get('Result') }}
        </div>
    @endif

@endsection

@section('table')

<div class="col-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <form class="forms-sample" action="{{ url('backend/moneda') }}" method="POST">
                @csrf

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="name" placeholder="Name" name="name" value="{{ old('name') }}" required>
                </div>
                <div class="form-group">
                    <label for="symbol">Symbol</label>
                    <input type="text" maxlength="5" minlength="1" class="form-control" id="symbol" placeholder="Symbol" name="symbol" value="{{ old('symbol') }}" required>
                </div>
                <div class="form-group">
                    <label for="country">Country</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="country" placeholder="Country" name="country" value="{{ old('country') }}" required>
                    </div>
                <div class="form-group">
                    <label for="number">Value</label>
                    <input type="number" maxlength="10" class="form-control" step="any" id="value" placeholder="Value" name="value" value="{{ old('value') }}" required>
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" class="form-control" id="date" placeholder="Date" name="date" value="{{ old('date') }}">
                </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                <a href="{{ url('backend/moneda') }}" class="btn btn-light">Cancel</a>
            </form>
        </div>
    </div>
</div>
@endsection