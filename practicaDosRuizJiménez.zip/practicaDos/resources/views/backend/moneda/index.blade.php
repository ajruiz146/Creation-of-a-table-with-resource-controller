@extends('backend.base')

@section('link')
<link rel="stylesheet" href="{{ url('assets/monedacss/styleMoneda.css') }}">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

@endsection

@section('messages')
    
    <a href="{{ url('backend/moneda/create') }}" class="btn btn-info btn-rounded btn-fw mdi mdi-plus"> Create</a>
   
    <br />
    <br />

    @if(Session::get('Op') == 'create')
        @if(Session::get('Result') == 1)
        <div class="alert alert-success" role="alert">
            Moneda (id: {{ Session::get('Id') }}) inserted correctly
        </div>
        @else
        <div class="alert alert-danger" role="alert">
        {{ Session::get('Result') }}
        </div>
        @endif
    @endif

    @if(Session::get('Op') == 'update')
        @if(Session::get('Result') == 1)
        <div class="alert alert-success" role="alert">
            Moneda (id: {{ Session::get('Id') }}) updated correctly
        </div>
        @else
        <div class="alert alert-danger" role="alert">
        {{ Session::get('Result') }}
        </div>
        @endif
    @endif

    @if(Session::get('Op') == 'delete')
        @if(Session::get('Result') == 1)
        <div class="alert alert-success" role="alert">
            Moneda (id: {{ Session::get('Id') }}) deleted correctly
        </div>
        @else
        <div class="alert alert-danger" role="alert">
        {{ Session::get('Result') }}
        </div>
        @endif
    @endif

@endsection

@section('tittle')

<h4>MONEDA - INDEX</h4>

@endsection

@section('table')
 
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Symbol</th>
            <th>Country</th>

            <th>Show</th>
            <th>Edit</th>
            <th>Delete</th>

        </tr>
    </thead>
    
    <tbody>
        @foreach($monedas as $moneda)
        <tr class="prueba">
            <td>{{ $moneda->id }}</td>
            <td>{{ $moneda->name }}</td>
            <td>{{ $moneda->symbol }}</td>
            <td>{{ $moneda->country }}</td>

            <td><a href="{{ url('backend/moneda/' . $moneda->id) }}"><i class="mdi mdi-eye"></i></a></td>
            <td><a href="{{ url('backend/moneda/' . $moneda->id . '/edit') }}"><i class="mdi mdi-lead-pencil"></i></a></td>
            <td><a href="#" class="linkDelete"><i class="mdi mdi-delete" data-id="{{ $moneda->id }}" data-toggle="modal" data-target="#exampleModal" data-name="{{ $moneda->name }}"></i></a></td>



        </tr>
        @endforeach
    </tbody>

    <form id="formDelete" action="{{ url('backend/moneda') }}" method="POST">
        @method('delete')
        @csrf
    </form>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Sure to delete?</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div id="add" class="modal-body">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-primary" name="deleteButton">Delete</button>
        </div>
        </div>
    </div>
    </div>

@endsection

@section('script')

<script src="{{ url('assets/monedajs/delete.js') }}"></script>

@endsection