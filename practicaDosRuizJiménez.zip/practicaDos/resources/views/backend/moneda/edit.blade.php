@extends('backend.base')

@section('link')

<link rel="stylesheet" href="{{ url('assets/monedacss/styleMoneda.css') }}">

@endsection

@section('tittle')

<h4>MONEDA - EDIT</h4>

@endsection

@section('messages')

    <a href="{{ url()->previous() }}" class="btn btn-info btn-rounded btn-fw mdi mdi-keyboard-backspace"> Back</a>
    <a href="{{ url('backend/moneda') }}" class="btn btn-info btn-rounded btn-fw mdi mdi-coin"> Monedas</a>
    <a href="#" class="btn btn-info btn-rounded btn-fw mdi mdi-delete" data-id="{{ $moneda->id }}" data-name="{{ $moneda->name }}" data-toggle="modal" data-target="#exampleModal"> Delete</a>

    <form id="formDelete" action="{{ url('backend/moneda') }}" method="POST">
        @method('delete')
        @csrf
    </form>
    
    <br>
    <br>
    

    @if(Session::get('Result') == 'Fail to update')
        <div class="alert alert-danger" role="alert">
            {{ Session::get('Result') }}
        </div>
    @endif

@endsection

@section('table')

<div class="col-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Moneda</h4>
            <form class="forms-sample" action="{{ url('backend/moneda/' . $moneda->id) }}" method="POST">
                @csrf
                @method('put')
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="name" placeholder="Name" name="name" value="{{ $moneda->name }}" required>
                </div>
                <div class="form-group">
                    <label for="symbol">Symbol</label>
                    <input type="text" maxlength="5" minlength="1" class="form-control" id="symbol" placeholder="Symbol" name="symbol" value="{{ $moneda->symbol }}" required>
                </div>
                <div class="form-group">
                    <label for="country">Country</label>
                    <input type="text" maxlength="50" minlength="1" class="form-control" id="country" placeholder="Country" name="country" value="{{ $moneda->country }}" required>
                    </div>
                <div class="form-group">
                    <label for="number">Value</label>
                    <input type="number" maxlength="10" class="form-control" id="value" placeholder="Value" name="value" value="{{ $moneda->value }}" required>
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" class="form-control" id="date" placeholder="Date" name="date" value="{{ $moneda->date }}">
                </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                <a href="{{ url('backend/moneda') }}" class="btn btn-light">Cancel</a>
            </form>
        </div>
    </div>
</div>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Sure to delete?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="add" class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" name="deleteButton">Delete</button>
            </div>
            </div>
        </div>
    </div>

@endsection

@section('script')

<script src="{{ url('assets/monedajs/delete.js') }}"></script>

@endsection