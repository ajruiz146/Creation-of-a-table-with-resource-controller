@extends('backend.base')

@section('link')

<link rel="stylesheet" href="{{ url('assets/monedacss/styleMoneda.css') }}">

@endsection

@section('tittle')

<h4>MONEDA - SHOW</h4>

@endsection

@section('messages')

    <a href="{{ url()->previous() }}" class="btn btn-info btn-rounded btn-fw mdi mdi-keyboard-backspace"> Back</a>
    <a href="{{ url('backend/moneda') }}" class="btn btn-info btn-rounded btn-fw mdi mdi-coin"> Monedas</a>
    <a href="#" class="btn btn-info btn-rounded btn-fw mdi mdi-delete" data-id="{{ $moneda->id }}" data-name="{{ $moneda->name }}" data-toggle="modal" data-target="#exampleModal"> Delete</a>

    <br />
    <br />

    <form id="formDelete" action="{{ url('backend/moneda') }}" method="POST">
        @method('delete')
        @csrf
    </form>

@endsection

@section('table')
    
    <thead>
        <tr>
            <th>Field</th>
            <th>Value</th>
        </tr>
    </thead>
    
    <tbody>
        
            <tr>
                <td><b>Id</b></td>
                <td>{{ $moneda->id }}</td>
            </tr>
            
            <tr>
                <td><b>Name</b></td>
                <td>{{ $moneda->name }}</td>
            </tr>
            
            <tr>
                <td><b>Symbol</b></td>
                <td>{{ $moneda->symbol }}</td>
            </tr>
            
            <tr>
                <td><b>Country</b></td>
                <td>{{ $moneda->country }}</td>
            </tr>
            
            <tr>
                <td><b>Value</b></td>
                <td>{{ $moneda->value }}</td> 
            </tr>
            
            @if($moneda->date)
            
            <tr>
                <td><b>Date</b></td>
                <td>{{ $moneda->date }}</td>
            </tr>
            
            @endif
            

    </tbody>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Sure to delete?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="add" class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" name="deleteButton">Delete</button>
            </div>
            </div>
        </div>
    </div>

@endsection

@section('script')

<script src="{{ url('assets/monedajs/delete.js') }}"></script>

@endsection