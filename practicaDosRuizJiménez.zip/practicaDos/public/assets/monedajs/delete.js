(function () {

    let linksDelete = document.getElementsByClassName('mdi mdi-delete');
    let secoundModal = document.getElementsByName("deleteButton");

    for (let i = 0; i < linksDelete.length; i++) {
        linksDelete[i].addEventListener('click', getValues);
    }

    for (let i = 0; i < individualDelete.length; i++) {
        individualDelete[i].addEventListener('click', getValues);
    }

    function getValues(event) {
        let id = event.target.dataset.id;
        let name = event.target.dataset.name;
        modalRefresh(id, name);
        for (let i = 0; i < secoundModal.length; i++) {
            secoundModal[i].addEventListener('click', function executeDelete() {
                var formDelete = document.getElementById('formDelete');
                formDelete.action += '/' + id;
                formDelete.submit();
            });
        }
    }

    function modalRefresh(id, name) {
        let add = document.getElementById("add");
        let elementText = document.getElementById("text");

        if (elementText) {
            add.removeChild(document.getElementById("text"));
        }

        let text = document.createElement("p");
        text.setAttribute("id", "text");
        text.innerHTML = 'Sure to delete ' + name + ' with id ' + id + '?';
        add.appendChild(text);
    }
})();